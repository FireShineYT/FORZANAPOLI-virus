# FORZANAPOLI-virus
This is the forza napoli virus.RUN THIS PROGRAM ONLY ON A VIRTUAL MACHINE OR YOU WILL DESTROY YOUR COMPUTER.You can use one of this programs: Virtualbox,VMware,Parallels(disconnect from the internet)
metti una VPN senno Rick ti viene in casa
